jQuery(document).on('ready', function () {

    if (!jQuery('#page_template').length)
    {
        jQuery('#page_custom_meta_box').hide();
    }

});