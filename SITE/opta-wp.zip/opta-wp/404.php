<?php get_header(); ?>
            <h1 class="center-text"><?php echo esc_html__('404 - Page Not Found', 'opta-wp');?></h1>
<?php get_footer(); ?>