Opta WP is WordPress theme crafted by <a href="http://cocobasic.com">Coco Basic</a>.
Theme live demo you can find on http://demo.cocobasic.com/opta-wp/
For any question you can reach us on cocobasicthemes@gmail.com